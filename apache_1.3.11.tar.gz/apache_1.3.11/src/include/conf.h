/*
 *  conf.h -- backward compatibility header for ap_config.h
 */

#ifdef __GNUC__
#warning "This header is obsolete, use ap_config.h instead"
#endif

#include "ap_config.h"
