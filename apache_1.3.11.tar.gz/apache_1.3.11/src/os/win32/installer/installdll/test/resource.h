//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test.rc
//
#define IDM_TEST                        102
#define IDI_TEST                        106
#define IDM_EXIT                        106
#define IDD_ABOUT                       107
#define IDD_SETDIRECTORY                109
#define IDM_ABOUT                       303
#define IDC_DIRECTORY                   1000
#define IDM_BEFOREEXIT                  40001
#define IDM_CONFIGURE                   40001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
