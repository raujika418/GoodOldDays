-- Character functions

minChar, maxChar        :: Char
minChar                 = '\0'
maxChar                 = '\255'