-- This file is created automatically.  Do not edit by hand.


--Base table offsets for the Native Code Generator
#define OFFSET_Dbl1 0
#define OFFSET_Dbl2 2
#define OFFSET_Flt1 4
#define OFFSET_Flt2 5
#define OFFSET_Flt3 6
#define OFFSET_Flt4 7
#define OFFSET_R1 8
#define OFFSET_R2 9
#define OFFSET_R3 10
#define OFFSET_R4 11
#define OFFSET_R5 12
#define OFFSET_R6 13
#define OFFSET_R7 14
#define OFFSET_R8 15
#define OFFSET_SpA 16
#define OFFSET_SuA 17
#define OFFSET_SpB 18
#define OFFSET_SuB 19
#define OFFSET_Hp -12
#define OFFSET_HpLim -11
#define OFFSET_Tag 22
#define OFFSET_Ret 23
#define OFFSET_Activity 24
#define OFFSET_StkO panic "OFFSET_StkO"
#define OFFSET_Liveness panic "OFFSET_Liveness"
#define SM_HP 0
#define SM_HPLIM 1
#define SM_ROOTNO 2
#define SM_ROOTS 3
#define SM_CAFLIST 4
#define SM_OLDROOTS 5
#define SM_OLDLIM 6
#define SM_OLDMUTUPLES 7
#define SM_MALLOCPTRLIST 8
#define SM_OLDMALLOCPTRLIST 9
#define SM_STABLEPOINTERTABLE 10
