module Trace where
trace x y = _trace x y
