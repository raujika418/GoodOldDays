module PreludeCore where

-- *** context missing ***
data Bool = False | True
	  deriving () -- NB
