main :: IO ()
main = interact id

-- 46,173 bytes/sec (600KB input)
