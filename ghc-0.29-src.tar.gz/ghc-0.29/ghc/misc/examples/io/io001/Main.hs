main = putStr "Hello, world\n"
