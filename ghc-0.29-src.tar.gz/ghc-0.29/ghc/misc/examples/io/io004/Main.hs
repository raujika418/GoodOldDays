import LibSystem (exitWith, ExitCode(..))

main = exitWith (ExitFailure 42)
