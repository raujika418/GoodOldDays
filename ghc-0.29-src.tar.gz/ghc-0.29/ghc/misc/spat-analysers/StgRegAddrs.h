/* Produced from: nm -n */

#define UpdReg 0x00b5098
#define SpA 0x00b50a0
#define SuA 0x00b50a8
#define SuB 0x00b50b0
#define SpB 0x00b50b8
#define Ret1 0x00b50e8
#define Ret2 0x00b50f0
#define Ret3 0x00b50f8
#define HpLim 0x00b5100
#define Hp 0x00b5108
#define RetVecReg 0x00b5110
#define TagReg 0x00b5118
#define Ret5 0x00b5120
#define Ret4 0x00b5130
#define Ret6 0x00b5138
#define Ret7 0x00b5140
#define Ret8 0x00b5148
