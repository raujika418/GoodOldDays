#include <stddef.h>
main(){size_t foo=sizeof(size_t);exit(0);}
