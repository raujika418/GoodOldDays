# line 3 "main/TopClosure.lc"
#include "rtsdefs.h"

EXTDATA(Main_mainPrimIO_closure);

P_ TopClosure = Main_mainPrimIO_closure;
