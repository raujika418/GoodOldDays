# line 3 "main/TopClosure13.lc"
#include "rtsdefs.h"

EXTDATA(Main_mainPrimIO13_closure);

P_ TopClosure = Main_mainPrimIO13_closure;
