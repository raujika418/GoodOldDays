#ifndef AUX_FILE_H
#define AUX_FILE_H

extern void PutAuxFile PROTO((FILE *));
extern void GetAuxFile PROTO((FILE *));

#endif /* AUX_FILE_H */
