#ifndef AXES_H
#define AXES_H

extern void Axes PROTO((void));

#endif /* AXES_H */
