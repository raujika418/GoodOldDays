#ifndef CURVES_H
#define CURVES_H

extern void Curves PROTO((void));
extern void CurvesInit PROTO((void));

extern floatish xpage PROTO((floatish));
extern floatish ypage PROTO((floatish));

#endif /* CURVES_H */
