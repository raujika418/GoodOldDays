#ifndef DEVIATION_H
#define DEVIATION_H

extern void Deviation  PROTO((void));
extern void Identorder PROTO((int));

#endif /* DEVIATION_H */
