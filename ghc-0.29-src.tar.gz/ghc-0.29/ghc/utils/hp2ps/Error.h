#ifndef ERROR_H
#define ERROR_H

extern void Error    (); /*PROTO((char *, ...)); */
extern void Disaster (); /* PROTO((char *, ...)); */
extern void Usage    (); /* PROTO((char *)); */

#endif /* ERROR_H */
