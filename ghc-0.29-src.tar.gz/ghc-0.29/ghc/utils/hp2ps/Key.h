#ifndef KEY_H
#define KEY_H

extern void Key PROTO((void));

#endif /* KEY_H */
