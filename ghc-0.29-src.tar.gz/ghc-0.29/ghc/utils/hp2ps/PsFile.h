#ifndef PS_FILE_H
#define PS_FILE_H

extern void PutPsFile PROTO((void));

#endif /* PS_FILE_H */
