#ifndef REORDER_H
#define REORDER_H

extern void Reorder  PROTO((void));
extern int  OrderOf  PROTO((char *));
extern void OrderFor PROTO((char *, int));

#endif /* REORDER_H */
