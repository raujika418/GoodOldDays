#ifndef SCALE_H
#define SCALE_H

extern floatish MaxCombinedHeight PROTO((void));
extern void     Scale PROTO((void));

#endif /* SCALE_H */
