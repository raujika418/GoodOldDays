#ifndef SHADE_H
#define SHADE_H

extern floatish ShadeOf  PROTO((char *));
extern void     ShadeFor PROTO((char *, floatish));
extern void     SetPSColour PROTO((floatish));

#endif /* SHADE_H */
