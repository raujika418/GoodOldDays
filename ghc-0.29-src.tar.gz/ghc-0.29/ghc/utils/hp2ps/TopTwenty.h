#ifndef TOP_TWENTY_H
#define TOP_TWENTY_H

extern void TopTwenty PROTO((void));

#endif /* TOP_TWENTY_H */
