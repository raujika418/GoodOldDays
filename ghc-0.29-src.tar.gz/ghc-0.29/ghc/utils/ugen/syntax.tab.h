#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	ID	258
#define	TYPE	259
#define	SEMICOL	260
#define	COLON	261
#define	END	262
#define	STDEF	263
#define	ENDDEF	264


extern YYSTYPE yylval;
