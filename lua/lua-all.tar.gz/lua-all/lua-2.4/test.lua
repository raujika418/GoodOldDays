print("Hello from Lua 2.4")
