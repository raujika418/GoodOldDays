print("Hello from ".._VERSION_)
