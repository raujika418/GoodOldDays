ary = [0, 0, 4, 5]
ary[1, 0] = [7]
print(ary, "\n")
