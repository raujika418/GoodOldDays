
case "t"
when /1/
  print(1, "\n")
when /t/
  print(3..5, "\n")
when /./
  print(2, "\n")
else
  print("else\n")
end
  
