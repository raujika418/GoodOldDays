print(+-1.0.hash,"\n")
print(-1.0.hash,"\n")
print((-1.0).hash,"\n")
print(-(1.0.hash),"\n")
