#load("lib/math.o")
include Math
sqrt(4)
print(Math.sqrt(257), "\n")
