this is a forwarding header
this is a header too.
  #! ruby
this is a trailing
#! ./ruby -v
print("tt\n")
__END__
this is a trailer
