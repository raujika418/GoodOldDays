if File._s("io.rb")
  print(File._z("io.rb", "io.rb\n")
#  print(File._s("io.rb"), ": io.rb\n")
end

for i in 1..5
end
