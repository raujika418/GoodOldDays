for i in 1..10
  print("test\n")
  break
  print("test2\n")
end
