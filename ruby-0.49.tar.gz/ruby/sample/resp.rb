undef kill
print(responds_to("kill"), "\n")
