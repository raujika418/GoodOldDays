print(system2("echo foobar"))
