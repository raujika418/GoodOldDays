#define RUBY_VERSION "0.49"
#define VERSION_DATE "18 Jul 94"
