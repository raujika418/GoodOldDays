/************************************************

  util.h -

  $Author$
  $Date$
  created at: Thu Mar  9 11:55:53 JST 1995

  Copyright (C) 1993-1996 Yukihiro Matsumoto

************************************************/
#ifndef UTIL_H
#define UTIL_H

unsigned long scan_hex();
unsigned long scan_oct();

#endif /* UTIL_H */
